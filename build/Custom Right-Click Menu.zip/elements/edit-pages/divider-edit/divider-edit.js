/*
 * Original can be found at https://github.com/SanderRonde/CustomRightClickMenu 
 * This code may only be used under the MIT style license found in the LICENSE.txt file 
**/
"use strict";var dividerEditProperties={item:{type:Object,value:{},notify:!0}},DE=function(){function a(){}return a.init=function(){this._init()},a.ready=function(){window.dividerEdit=this},a}();DE.is="divider-edit",DE.behaviors=[Polymer.NodeEditBehavior],DE.properties=dividerEditProperties,Polymer(DE);